## Collaborators

yo-yo is only possible due to the excellent work of the following collaborators:

<table><tbody><tr><th align="left">maxogden</th><td><a href="https://github.com/maxogden">GitHub/maxogden</a></td></tr>
<tr><th align="left">shama</th><td><a href="https://github.com/shama">GitHub/shama</a></td></tr>
<tr><th align="left">yoshuawuyts</th><td><a href="https://github.com/yoshuawuyts">GitHub/yoshuawuyts</a></td></tr>
<tr><th align="left">freeman-lab</th><td><a href="https://github.com/freeman-lab">GitHub/freeman-lab</a></td></tr>
</tbody></table>
